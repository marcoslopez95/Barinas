# Cómo contribuir

Este proyecto es software libre y todos los desarrolladores son bienvenidos.
Puedes consultar la lista de tareas a realizar, la documentación y el chat
para programadores en nuestra página web:

https://facturascripts.com/colabora